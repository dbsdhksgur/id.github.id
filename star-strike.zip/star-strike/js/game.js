/* ==========================================================
   STAR STRIKE - 갤러거 스타일 아케이드 슈팅 게임
   순수 HTML5 Canvas + JavaScript (외부 라이브러리 없음)
   ========================================================== */
(() => {
  'use strict';

  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');
  const W = canvas.width;   // 480
  const H = canvas.height;  // 640
  const TAU = Math.PI * 2;
  ctx.imageSmoothingEnabled = false;

  if (document.fonts && document.fonts.load) {
    document.fonts.load('12px "Press Start 2P"').catch(() => {});
  }

  /* ---------------------------------------------------------
     유틸
     --------------------------------------------------------- */
  const rand = (a, b) => a + Math.random() * (b - a);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const lerp = (a, b, t) => a + (b - a) * t;
  const range = (a, b) => Array.from({ length: b - a + 1 }, (_, i) => a + i);
  const angleDiff = (a, b) => ((b - a + Math.PI) % TAU + TAU) % TAU - Math.PI;

  function bezier(p, t) {
    const u = 1 - t;
    const a = u * u * u, b = 3 * u * u * t, c = 3 * u * t * t, d = t * t * t;
    return {
      x: a * p[0].x + b * p[1].x + c * p[2].x + d * p[3].x,
      y: a * p[0].y + b * p[1].y + c * p[2].y + d * p[3].y,
    };
  }

  /* ---------------------------------------------------------
     픽셀 스프라이트 (문자열 도트 → 오프스크린 캔버스)
     --------------------------------------------------------- */
  const SCALE = 3;
  const PAL = {
    w: '#ffffff', r: '#ff4466', b: '#3aa0ff', y: '#ffd23a', g: '#2ee6a6',
  };

  const SPR = {
    player: [[
      '......w......',
      '......w......',
      '.....www.....',
      '.....www.....',
      '..r..www..r..',
      '.rr..www..rr.',
      '.rrwwwwwwwrr.',
      'rrrwwwbwwwrrr',
      'rr..wwwww..rr',
      'r...rr.rr...r',
    ]],
    bee: [
      [
        '..y.....y..',
        '...y...y...',
        '..yyyyyyy..',
        '.yybyyybyy.',
        'yyyyyyyyyyy',
        'y.yyyyyyy.y',
        'y.y.....y.y',
        '...yy.yy...',
      ],
      [
        'y.........y',
        '.y.......y.',
        '..yyyyyyy..',
        '.yybyyybyy.',
        'yyyyyyyyyyy',
        '..yyyyyyy..',
        '..y.....y..',
        '...yy.yy...',
      ],
    ],
    butterfly: [
      [
        'r.........r',
        'rr..rrr..rr',
        'rrrrrrrrrrr',
        'rrwbrrrbwrr',
        'rrrrrrrrrrr',
        '.rrr.r.rrr.',
        '..rr...rr..',
        '..r.....r..',
      ],
      [
        '.r.......r.',
        'rrr.rrr.rrr',
        'rrrrrrrrrrr',
        'rrwbrrrbwrr',
        'rrrrrrrrrrr',
        '.rrr.r.rrr.',
        '..rr...rr..',
        '..r.....r..',
      ],
    ],
    boss: [
      [
        'g...........g',
        'gg..ggggg..gg',
        'ggggggggggggg',
        'ggwwgggggwwgg',
        'gggwwgggwwggg',
        'gggbgggggbggg',
        '.gg.ggggg.gg.',
        '..gg..ggg..gg',
        '..g.......g..',
      ],
      [
        '..g.......g..',
        'g..ggggggg..g',
        'ggggggggggggg',
        'ggwwgggggwwgg',
        'gggwwgggwwggg',
        'gggbgggggbggg',
        '.gg.ggggg.gg.',
        '..gg..ggg..gg',
        '..g.......g..',
      ],
    ],
  };

  const spriteCache = new Map();
  function getSprite(name, frame = 0, variant = '') {
    const key = name + '|' + frame + '|' + variant;
    let c = spriteCache.get(key);
    if (!c) {
      const frames = SPR[name];
      const rows = frames[frame % frames.length];
      c = document.createElement('canvas');
      c.width = rows[0].length * SCALE;
      c.height = rows.length * SCALE;
      const g = c.getContext('2d');
      for (let y = 0; y < rows.length; y++) {
        for (let x = 0; x < rows[y].length; x++) {
          const ch = rows[y][x];
          if (ch === '.') continue;
          let color = PAL[ch];
          if (variant === 'flash') color = '#ffffff';
          else if (variant === 'hurt' && ch === 'g') color = '#c58bff';
          g.fillStyle = color;
          g.fillRect(x * SCALE, y * SCALE, SCALE, SCALE);
        }
      }
      spriteCache.set(key, c);
    }
    return c;
  }

  /* ---------------------------------------------------------
     사운드 (WebAudio, 외부 파일 없음)
     --------------------------------------------------------- */
  let actx = null;
  let muted = false;

  function ensureAudio() {
    if (!actx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (AC) { try { actx = new AC(); } catch (_) { actx = null; } }
    }
    if (actx && actx.state === 'suspended') actx.resume();
  }

  function tone(freq, dur, type = 'square', vol = 0.05, slide = 0, delay = 0) {
    if (!actx || muted) return;
    const t0 = actx.currentTime + delay;
    const o = actx.createOscillator();
    const g = actx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t0);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t0 + dur);
    g.gain.setValueAtTime(vol, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g); g.connect(actx.destination);
    o.start(t0); o.stop(t0 + dur + 0.02);
  }

  function noise(dur, vol = 0.12) {
    if (!actx || muted) return;
    const n = Math.floor(actx.sampleRate * dur);
    const buf = actx.createBuffer(1, n, actx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / n);
    const src = actx.createBufferSource();
    src.buffer = buf;
    const g = actx.createGain(); g.gain.value = vol;
    const f = actx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 1800;
    src.connect(f); f.connect(g); g.connect(actx.destination);
    src.start();
  }

  const sfx = {
    shoot: () => tone(900, 0.09, 'square', 0.03, -600),
    hit:   () => tone(320, 0.1, 'sawtooth', 0.05, -180),
    kill:  () => { noise(0.22, 0.1); tone(240, 0.18, 'square', 0.04, -160); },
    boom:  () => { noise(0.6, 0.2); tone(120, 0.5, 'sawtooth', 0.07, -80); },
    power: () => { tone(523, 0.09, 'square', 0.05); tone(784, 0.09, 'square', 0.05, 0, 0.09); tone(1046, 0.14, 'square', 0.05, 0, 0.18); },
    start: () => { [392, 523, 659, 784].forEach((f, i) => tone(f, 0.12, 'square', 0.05, 0, i * 0.12)); },
    stage: () => { [523, 659].forEach((f, i) => tone(f, 0.1, 'square', 0.04, 0, i * 0.1)); },
    over:  () => { [392, 330, 262, 196].forEach((f, i) => tone(f, 0.25, 'triangle', 0.07, 0, i * 0.25)); },
  };

  /* ---------------------------------------------------------
     게임 데이터
     --------------------------------------------------------- */
  const GRID_X = 60, GRID_Y = 96, CELL_W = 40, CELL_H = 36;

  const FORMATION = [
    { type: 'boss',      cols: range(3, 6) },
    { type: 'butterfly', cols: range(1, 8) },
    { type: 'butterfly', cols: range(1, 8) },
    { type: 'bee',       cols: range(0, 9) },
    { type: 'bee',       cols: range(0, 9) },
  ];

  const TYPES = {
    bee:       { r: 13, form: 50,  dive: 100, hp: 1, color: '#ffd23a' },
    butterfly: { r: 14, form: 80,  dive: 160, hp: 1, color: '#ff4466' },
    boss:      { r: 17, form: 150, dive: 400, hp: 2, color: '#2ee6a6' },
  };

  const CHALLENGE_PATHS = [
    [{ x: -30, y: 140 }, { x: W * 0.95, y: 40 }, { x: W * 0.05, y: 430 }, { x: W + 30, y: 330 }],
    [{ x: W * 0.5, y: -30 }, { x: W * 0.05, y: 220 }, { x: W * 0.95, y: 330 }, { x: W * 0.5, y: H + 30 }],
    [{ x: -30, y: 380 }, { x: W * 0.9, y: 420 }, { x: W * 0.1, y: 160 }, { x: W + 30, y: -30 }],
  ];

  const game = {
    state: 'title',            // title | play | paused | gameover
    stage: 1, score: 0, hi: 0, time: 0,
    intro: 0, cleared: false, clearT: 0, overT: 0, lockT: 0,
    challenge: false, hits: 0, total: 40, bonusText: '', perfect: false,
    diveT: 2, shootT: 1.5, nextExtra: 20000, shake: 0,
    enemies: [], pBullets: [], eBullets: [], parts: [], pops: [], powerups: [],
  };

  const player = {
    x: W / 2, y: H - 56, alive: true, respawn: 0, invuln: 0,
    lives: 2, dual: 0, cd: 0,
  };

  try { game.hi = parseInt(localStorage.getItem('starstrike-hi'), 10) || 0; } catch (_) { /* ignore */ }

  const keys = { left: false, right: false, fire: false };

  /* ---------------------------------------------------------
     배경 별
     --------------------------------------------------------- */
  const STAR_COLORS = ['#ffffff', '#99ccff', '#ffcc99', '#cc99ff'];
  const stars = Array.from({ length: 90 }, () => ({
    x: rand(0, W), y: rand(0, H), s: rand(20, 110), r: rand(0.6, 1.8),
    p: rand(0, TAU), c: STAR_COLORS[(Math.random() * STAR_COLORS.length) | 0],
  }));

  function updateStars(dt) {
    for (const s of stars) {
      s.y += s.s * dt;
      if (s.y > H) { s.y = -2; s.x = rand(0, W); }
    }
  }

  function drawStars() {
    for (const s of stars) {
      const tw = 0.5 + 0.5 * Math.sin(game.time * 3 + s.p);
      ctx.globalAlpha = 0.3 + 0.7 * tw * (s.s / 110);
      ctx.fillStyle = s.c;
      ctx.fillRect(s.x, s.y, s.r, s.r * (1 + s.s / 90));
    }
    ctx.globalAlpha = 1;
  }

  /* ---------------------------------------------------------
     게임 흐름
     --------------------------------------------------------- */
  function saveHi() {
    try { localStorage.setItem('starstrike-hi', String(game.hi)); } catch (_) { /* ignore */ }
  }

  function addScore(n) {
    game.score += n;
    if (game.score > game.hi) game.hi = game.score;
    if (game.score >= game.nextExtra) {
      player.lives++;
      game.nextExtra += game.nextExtra === 20000 ? 50000 : 70000;
      game.pops.push({ x: W / 2, y: H - 90, text: '1UP!', life: 1.4 });
      sfx.power();
    }
  }

  function startGame() {
    ensureAudio();
    game.score = 0;
    game.nextExtra = 20000;
    Object.assign(player, { x: W / 2, alive: true, respawn: 0, invuln: 0, lives: 2, dual: 0, cd: 0 });
    game.pBullets = []; game.eBullets = []; game.parts = [];
    game.pops = []; game.powerups = [];
    game.overT = 0;
    game.state = 'play';
    sfx.start();
    startStage(1);
  }

  function startStage(n) {
    game.stage = n;
    game.challenge = n % 4 === 3;
    game.intro = 2.2;
    game.cleared = false;
    game.clearT = 0;
    game.hits = 0;
    game.total = 40;
    game.diveT = 2.5;
    game.shootT = 1.5;
    game.eBullets = [];
    if (game.challenge) spawnChallenge(); else spawnFormation();
    sfx.stage();
  }

  function makeEnemy(type, row, col) {
    const T = TYPES[type];
    return {
      type, row, col, r: T.r, hp: T.hp, maxHp: T.hp,
      x: -100, y: -100, angle: 0, state: 'enter', visible: false,
      delay: 0, t: 0, dur: 2.6, path: null, flash: 0,
      dead: false, escaped: false, started: false, shots: 0, nextShot: 0,
    };
  }

  function slotPos(e) {
    return {
      x: GRID_X + e.col * CELL_W + Math.sin(game.time * 0.8) * 22,
      y: GRID_Y + e.row * CELL_H + Math.sin(game.time * 1.7 + e.col * 0.2) * 2,
    };
  }

  function spawnFormation() {
    const list = [];
    FORMATION.forEach((row, ri) => row.cols.forEach(c => list.push(makeEnemy(row.type, ri, c))));
    list.forEach((e, i) => {
      const g = Math.floor(i / 8), k = i % 8, s = g % 2;
      const j = () => rand(-18, 18);
      e.delay = 0.2 + g * 1.5 + k * 0.14;
      e.dur = 2.7;
      e.path = [
        { x: (s ? W - 70 : 70) + j(), y: -30 },
        { x: s ? 30 : W - 30, y: 250 + j() },
        { x: s ? W - 30 : 30, y: 500 + j() },
        slotPos(e),
      ];
    });
    game.enemies = list;
  }

  function spawnChallenge() {
    const types = ['bee', 'butterfly', 'bee', 'butterfly', 'bee'];
    const defs = [[0, false], [0, true], [1, false], [2, false], [2, true]];
    const list = [];
    defs.forEach(([ti, mirror], g) => {
      for (let k = 0; k < 8; k++) {
        const e = makeEnemy(types[g], 0, list.length);
        e.delay = 0.2 + g * 2.0 + k * 0.2;
        e.dur = 3.6;
        e.path = CHALLENGE_PATHS[ti].map(p => ({ x: mirror ? W - p.x : p.x, y: p.y }));
        list.push(e);
      }
    });
    game.enemies = list;
  }

  /* ---------------------------------------------------------
     입력
     --------------------------------------------------------- */
  const KEYMAP = {
    ArrowLeft: 'left', KeyA: 'left',
    ArrowRight: 'right', KeyD: 'right',
    Space: 'fire', KeyZ: 'fire', ArrowUp: 'fire',
  };

  function tryStart() {
    if (game.state === 'title' || (game.state === 'gameover' && game.lockT <= 0)) startGame();
    else if (game.state === 'paused') game.state = 'play';
  }

  function togglePause() {
    if (game.state === 'play') game.state = 'paused';
    else if (game.state === 'paused') game.state = 'play';
  }

  window.addEventListener('keydown', e => {
    if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Space'].includes(e.code)) e.preventDefault();
    ensureAudio();
    const k = KEYMAP[e.code];
    if (k) keys[k] = true;
    if (e.repeat) return;
    if (e.code === 'Enter' || e.code === 'Space') tryStart();
    if (e.code === 'KeyP' || e.code === 'Escape') togglePause();
    if (e.code === 'KeyM') muted = !muted;
  });

  window.addEventListener('keyup', e => {
    const k = KEYMAP[e.code];
    if (k) keys[k] = false;
  });

  window.addEventListener('blur', () => {
    keys.left = keys.right = keys.fire = false;
    if (game.state === 'play') game.state = 'paused';
  });

  document.addEventListener('visibilitychange', () => {
    if (document.hidden && game.state === 'play') game.state = 'paused';
  });

  canvas.addEventListener('pointerdown', () => { ensureAudio(); tryStart(); });

  document.querySelectorAll('.btn').forEach(btn => {
    const k = btn.dataset.key;
    const on = ev => { ev.preventDefault(); ensureAudio(); keys[k] = true; if (k === 'fire') tryStart(); };
    const off = ev => { ev.preventDefault(); keys[k] = false; };
    btn.addEventListener('pointerdown', on);
    ['pointerup', 'pointerleave', 'pointercancel'].forEach(ev => btn.addEventListener(ev, off));
  });

  /* ---------------------------------------------------------
     이펙트
     --------------------------------------------------------- */
  function explode(x, y, color, n = 14) {
    for (let i = 0; i < n; i++) {
      const a = rand(0, TAU), s = rand(40, 200), life = rand(0.3, 0.75);
      game.parts.push({
        x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s,
        life, max: life, color: i % 3 === 0 ? '#ffffff' : color, size: rand(1.5, 3.6),
      });
    }
  }

  /* ---------------------------------------------------------
     플레이어
     --------------------------------------------------------- */
  function shipOffsets() { return player.dual > 0 ? [-16, 16] : [0]; }

  function playerShoot() {
    const offs = shipOffsets();
    const max = player.dual > 0 ? 6 : 3;
    if (game.pBullets.length + offs.length > max) return;
    for (const o of offs) game.pBullets.push({ x: player.x + o, y: player.y - 18, vy: -640, dead: false });
    player.cd = 0.2;
    sfx.shoot();
  }

  function playerHit() {
    if (!player.alive || player.invuln > 0) return;
    player.alive = false;
    explode(player.x, player.y, '#7fd2ff', 28);
    sfx.boom();
    game.shake = 0.5;
    if (player.lives > 0) {
      player.lives--;
      player.respawn = 1.8;
    } else {
      game.overT = 2.8;
      sfx.over();
    }
  }

  function updatePlayer(dt) {
    if (player.dual > 0) player.dual = Math.max(0, player.dual - dt);
    if (!player.alive) {
      if (game.overT <= 0) {
        player.respawn -= dt;
        if (player.respawn <= 0) {
          player.alive = true; player.x = W / 2; player.invuln = 2.2; player.dual = 0;
        }
      }
      return;
    }
    const dir = (keys.right ? 1 : 0) - (keys.left ? 1 : 0);
    const margin = 22 + (player.dual > 0 ? 16 : 0);
    player.x = clamp(player.x + dir * 300 * dt, margin, W - margin);
    player.cd -= dt;
    player.invuln -= dt;
    if (keys.fire && player.cd <= 0) playerShoot();
  }

  /* ---------------------------------------------------------
     적
     --------------------------------------------------------- */
  const maxEnemyBullets = () => Math.min(3 + Math.floor(game.stage / 2), 8);
  const bulletSpeed = () => 170 + Math.min(game.stage, 12) * 12;

  function fireAt(e) {
    if (!player.alive || game.eBullets.length >= maxEnemyBullets()) return;
    const dx = player.x - e.x;
    const dy = Math.max(40, player.y - e.y);
    const a = clamp(Math.atan2(dx, dy), -0.7, 0.7);
    const sp = bulletSpeed();
    game.eBullets.push({ x: e.x, y: e.y + 10, vx: Math.sin(a) * sp, vy: Math.cos(a) * sp, dead: false });
  }

  function startDive(e, shared) {
    e.state = 'dive';
    e.started = !!shared ? false : true;
    e.t = shared ? -0.12 : 0;
    e.dur = Math.max(2.0, 3.4 - game.stage * 0.08);
    e.shots = e.type === 'bee' ? 1 : 2;
    e.nextShot = rand(0.4, 0.9);
    const p0 = { x: e.x, y: e.y };
    if (shared) {
      e.path = [p0, ...shared.path.slice(1).map(p => ({ x: p.x + shared.dx, y: p.y }))];
      return;
    }
    const swing = Math.random() < 0.5 ? -1 : 1;
    e.path = [
      p0,
      { x: clamp(e.x + swing * rand(80, 160), 30, W - 30), y: e.y + rand(80, 160) },
      { x: clamp(player.x + rand(-50, 50), 30, W - 30), y: H * 0.55 },
      { x: rand(40, W - 40), y: H + 40 },
    ];
    if (e.type === 'boss') {
      const escorts = game.enemies.filter(o =>
        o.state === 'form' && o.type === 'butterfly' && Math.abs(o.col - e.col) <= 1);
      escorts.sort(() => Math.random() - 0.5);
      escorts.slice(0, 2).forEach(o => startDive(o, { path: e.path, dx: o.x - e.x }));
    }
  }

  function updateEnemy(e, dt) {
    const px = e.x, py = e.y;
    if (e.flash > 0) e.flash -= dt;

    if (e.state === 'enter') {
      if (e.delay > 0) {
        e.delay -= dt;
        if (e.delay > 0) return;
        e.visible = true;
        e.x = e.path[0].x; e.y = e.path[0].y;
        return;
      }
      e.t += dt / e.dur;
      if (!game.challenge) e.path[3] = slotPos(e);
      const p = bezier(e.path, Math.min(e.t, 1));
      e.x = p.x; e.y = p.y;
      if (e.t >= 1) {
        if (game.challenge) {
          e.escaped = true;
        } else {
          e.state = 'form';
          const s = slotPos(e); e.x = s.x; e.y = s.y;
        }
      }
    } else if (e.state === 'form') {
      const s = slotPos(e);
      e.x = s.x; e.y = s.y;
    } else if (e.state === 'dive') {
      e.t += dt / e.dur;
      if (e.t < 0) {
        const s = slotPos(e); e.x = s.x; e.y = s.y;
      } else {
        if (!e.started) { e.path[0] = { x: e.x, y: e.y }; e.started = true; }
        const p = bezier(e.path, Math.min(e.t, 1));
        e.x = p.x; e.y = p.y;
        e.nextShot -= dt;
        if (e.nextShot <= 0 && e.shots > 0 && e.y > 90 && e.y < H * 0.62) {
          fireAt(e); e.shots--; e.nextShot = rand(0.5, 0.9);
        }
        if (e.t >= 1) { e.state = 'return'; e.t = 0; e.y = -30; }
      }
    } else if (e.state === 'return') {
      e.t += dt / 1.0;
      const s = slotPos(e);
      const k = Math.min(e.t, 1);
      e.x = s.x;
      e.y = lerp(-30, s.y, k * k * (3 - 2 * k));
      if (e.t >= 1) { e.state = 'form'; e.x = s.x; e.y = s.y; }
    }

    let target = e.angle;
    if (e.state === 'form') {
      target = 0;
    } else {
      const dx = e.x - px, dy = e.y - py;
      if (dx * dx + dy * dy > 0.01) target = Math.atan2(dy, dx) - Math.PI / 2;
    }
    e.angle += angleDiff(e.angle, target) * Math.min(1, dt * 9);
  }

  function enemyAI(dt) {
    if (game.challenge) return;
    const entered = game.enemies.every(e => e.state !== 'enter');
    if (entered) {
      game.diveT -= dt;
      const diving = game.enemies.filter(e => e.state === 'dive').length;
      const maxDive = Math.min(2 + Math.floor(game.stage / 2), 6);
      if (game.diveT <= 0 && diving < maxDive) {
        const form = game.enemies.filter(e => e.state === 'form');
        if (form.length) {
          startDive(form[(Math.random() * form.length) | 0]);
          const few = game.enemies.length <= 6 ? 0.6 : 1;
          game.diveT = Math.max(0.5, 2.0 - game.stage * 0.12) * rand(0.7, 1.2) * few;
        }
      }
    }
    game.shootT -= dt;
    if (game.shootT <= 0) {
      const pool = game.enemies.filter(e => e.visible && (e.state === 'form' || e.state === 'enter'));
      if (pool.length) fireAt(pool[(Math.random() * pool.length) | 0]);
      game.shootT = Math.max(0.5, 1.6 - game.stage * 0.1) * rand(0.7, 1.3);
    }
  }

  function killEnemy(e) {
    e.dead = true;
    const T = TYPES[e.type];
    const diving = e.state === 'dive';
    const pts = game.challenge ? 100 : (diving ? T.dive : T.form);
    addScore(pts);
    if (game.challenge) game.hits++;
    if (diving || game.challenge) game.pops.push({ x: e.x, y: e.y, text: String(pts), life: 0.9 });
    explode(e.x, e.y, T.color, e.type === 'boss' ? 22 : 14);
    sfx.kill();
    if (e.type === 'boss' && diving && !game.challenge) game.powerups.push({ x: e.x, y: e.y });
  }

  function hitEnemy(e) {
    e.hp--;
    if (e.hp <= 0) killEnemy(e);
    else { e.flash = 0.1; sfx.hit(); }
  }

  /* ---------------------------------------------------------
     업데이트
     --------------------------------------------------------- */
  function collisions() {
    for (const b of game.pBullets) {
      for (const e of game.enemies) {
        if (e.dead || !e.visible) continue;
        if (Math.abs(b.x - e.x) < e.r + 2 && Math.abs(b.y - e.y) < e.r + 6) {
          b.dead = true;
          hitEnemy(e);
          break;
        }
      }
    }
    game.pBullets = game.pBullets.filter(b => !b.dead && b.y > -20);
    game.enemies = game.enemies.filter(e => !e.dead);

    if (player.alive && player.invuln <= 0) {
      for (const o of shipOffsets()) {
        const px = player.x + o, py = player.y;
        for (const b of game.eBullets) {
          if (!b.dead && (b.x - px) ** 2 + (b.y - py) ** 2 < 11 * 11) { b.dead = true; playerHit(); }
        }
        for (const e of game.enemies) {
          if (e.visible && !e.dead && (e.x - px) ** 2 + (e.y - py) ** 2 < (e.r + 8) ** 2) {
            killEnemy(e); playerHit();
          }
        }
      }
    }
    game.eBullets = game.eBullets.filter(b => !b.dead);
    game.enemies = game.enemies.filter(e => !e.dead);
  }

  function update(dt) {
    game.time += dt;
    if (game.lockT > 0) game.lockT -= dt;
    updateStars(dt);

    if (game.state === 'gameover') {
      updateParticles(dt);
      return;
    }
    if (game.state !== 'play') return;

    updatePlayer(dt);

    if (game.intro > 0) {
      game.intro -= dt;
    } else {
      for (const e of game.enemies) updateEnemy(e, dt);
      game.enemies = game.enemies.filter(e => !e.escaped && !e.dead);
      enemyAI(dt);
    }

    for (const b of game.pBullets) b.y += b.vy * dt;
    for (const b of game.eBullets) {
      b.x += b.vx * dt; b.y += b.vy * dt;
      if (b.y > H + 10 || b.x < -10 || b.x > W + 10) b.dead = true;
    }

    for (const p of game.powerups) {
      p.y += 90 * dt;
      if (player.alive && Math.abs(p.x - player.x) < 26 && Math.abs(p.y - player.y) < 22) {
        p.dead = true;
        player.dual = 14;
        addScore(500);
        game.pops.push({ x: p.x, y: p.y - 10, text: 'DUAL!', life: 1.0 });
        sfx.power();
      }
      if (p.y > H + 20) p.dead = true;
    }
    game.powerups = game.powerups.filter(p => !p.dead);

    collisions();
    updateParticles(dt);

    // 스테이지 클리어
    if (game.overT > 0) {
      game.overT -= dt;
      if (game.overT <= 0) endGame();
      return;
    }
    if (game.intro <= 0 && game.enemies.length === 0 && !game.cleared) {
      game.cleared = true;
      if (game.challenge) {
        game.perfect = game.hits === game.total;
        const bonus = game.perfect ? 10000 : game.hits * 100;
        addScore(bonus);
        game.bonusText = String(bonus);
        game.clearT = 3.6;
      } else {
        game.clearT = 1.4;
      }
    }
    if (game.cleared) {
      game.clearT -= dt;
      if (game.clearT <= 0) startStage(game.stage + 1);
    }
  }

  function updateParticles(dt) {
    for (const p of game.parts) {
      p.x += p.vx * dt; p.y += p.vy * dt;
      p.vx *= 0.97; p.vy *= 0.97;
      p.life -= dt;
    }
    game.parts = game.parts.filter(p => p.life > 0);
    for (const p of game.pops) { p.life -= dt; p.y -= 22 * dt; }
    game.pops = game.pops.filter(p => p.life > 0);
    if (game.shake > 0) game.shake = Math.max(0, game.shake - dt);
  }

  function endGame() {
    game.state = 'gameover';
    game.lockT = 1.0;
    saveHi();
  }

  /* ---------------------------------------------------------
     그리기
     --------------------------------------------------------- */
  function text(str, x, y, size = 12, color = '#fff', align = 'left') {
    ctx.font = `${size}px "Press Start 2P", monospace`;
    ctx.textAlign = align;
    ctx.textBaseline = 'middle';
    ctx.fillStyle = 'rgba(0,0,0,0.6)';
    ctx.fillText(str, x + 2, y + 2);
    ctx.fillStyle = color;
    ctx.fillText(str, x, y);
  }

  function drawSprite(spr, x, y, scale = 1, angle = 0) {
    ctx.save();
    ctx.translate(Math.round(x), Math.round(y));
    if (angle) ctx.rotate(angle);
    ctx.drawImage(spr, -spr.width * scale / 2, -spr.height * scale / 2, spr.width * scale, spr.height * scale);
    ctx.restore();
  }

  function drawEnemy(e) {
    if (!e.visible) return;
    const frame = Math.floor(game.time * 4 + e.col) % 2;
    const base = e.type === 'boss' && e.hp < e.maxHp ? 'hurt' : '';
    drawSprite(getSprite(e.type, frame, base), e.x, e.y, 1, e.angle);
    if (e.flash > 0) {
      ctx.globalAlpha = 0.7;
      drawSprite(getSprite(e.type, frame, 'flash'), e.x, e.y, 1, e.angle);
      ctx.globalAlpha = 1;
    }
  }

  function drawPlayer() {
    if (!player.alive) return;
    if (player.invuln > 0 && Math.floor(game.time * 14) % 2 === 0) return;
    const spr = getSprite('player');
    for (const o of shipOffsets()) {
      drawSprite(spr, player.x + o, player.y);
      // 엔진 불꽃
      const f = 4 + Math.random() * 4;
      ctx.fillStyle = '#ffb347';
      ctx.fillRect(player.x + o - 3, player.y + 15, 6, f);
      ctx.fillStyle = '#fff3b0';
      ctx.fillRect(player.x + o - 1, player.y + 15, 2, f - 1);
    }
  }

  function drawBullets() {
    for (const b of game.pBullets) {
      ctx.fillStyle = '#7fe8ff';
      ctx.fillRect(b.x - 1.5, b.y - 8, 3, 14);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(b.x - 0.5, b.y - 8, 1, 14);
    }
    for (const b of game.eBullets) {
      ctx.fillStyle = 'rgba(255,120,60,0.35)';
      ctx.beginPath(); ctx.arc(b.x, b.y, 7, 0, TAU); ctx.fill();
      ctx.fillStyle = '#ff7a3c';
      ctx.beginPath(); ctx.arc(b.x, b.y, 4, 0, TAU); ctx.fill();
      ctx.fillStyle = '#fff';
      ctx.beginPath(); ctx.arc(b.x, b.y, 1.8, 0, TAU); ctx.fill();
    }
  }

  function drawPowerups() {
    for (const p of game.powerups) {
      const pulse = 1 + Math.sin(game.time * 8) * 0.1;
      ctx.fillStyle = 'rgba(58,160,255,0.3)';
      ctx.beginPath(); ctx.arc(p.x, p.y, 16 * pulse, 0, TAU); ctx.fill();
      ctx.fillStyle = '#16307a';
      ctx.beginPath(); ctx.arc(p.x, p.y, 11, 0, TAU); ctx.fill();
      ctx.lineWidth = 2; ctx.strokeStyle = '#3aa0ff';
      ctx.stroke();
      text('D', p.x, p.y + 1, 10, '#ffffff', 'center');
    }
  }

  function drawParticles() {
    for (const p of game.parts) {
      ctx.globalAlpha = clamp(p.life / p.max, 0, 1);
      ctx.fillStyle = p.color;
      ctx.fillRect(p.x, p.y, p.size, p.size);
    }
    ctx.globalAlpha = 1;
    for (const p of game.pops) {
      ctx.globalAlpha = clamp(p.life * 1.5, 0, 1);
      text(p.text, p.x, p.y, 9, '#ffd23a', 'center');
    }
    ctx.globalAlpha = 1;
  }

  function drawHUD() {
    text('1UP', 16, 16, 10, '#ff4466');
    text(String(game.score).padStart(6, '0'), 16, 34, 12, '#ffffff');
    text('HI-SCORE', W / 2, 16, 10, '#ff4466', 'center');
    text(String(game.hi).padStart(6, '0'), W / 2, 34, 12, '#ffffff', 'center');
    text('STAGE ' + game.stage, W - 16, 16, 10, '#55ccff', 'right');
    if (muted) text('MUTE', W - 16, 34, 8, '#7f95b5', 'right');

    const icon = getSprite('player');
    for (let i = 0; i < player.lives; i++) {
      drawSprite(icon, 28 + i * 30, H - 22, 0.6);
    }
    if (player.dual > 0) {
      text('DUAL', W - 16, H - 28, 9, '#3aa0ff', 'right');
      ctx.fillStyle = '#16307a';
      ctx.fillRect(W - 96, H - 18, 80, 6);
      ctx.fillStyle = '#3aa0ff';
      ctx.fillRect(W - 96, H - 18, 80 * (player.dual / 14), 6);
    }
  }

  function drawBanners() {
    if (game.state === 'play' && game.intro > 0) {
      const blink = Math.floor(game.time * 5) % 2 === 0;
      text('STAGE ' + game.stage, W / 2, H / 2 - 20, 20, '#ffffff', 'center');
      if (game.challenge && blink) text('CHALLENGING STAGE', W / 2, H / 2 + 20, 14, '#ffd23a', 'center');
      else if (!game.challenge) text('READY!', W / 2, H / 2 + 20, 14, '#55ccff', 'center');
    }
    if (game.cleared && game.overT <= 0) {
      if (game.challenge) {
        text('NUMBER OF HITS', W / 2, 250, 14, '#55ccff', 'center');
        text(String(game.hits), W / 2, 290, 24, '#ffd23a', 'center');
        text('BONUS ' + game.bonusText, W / 2, 335, 14, '#ffffff', 'center');
        if (game.perfect && Math.floor(game.time * 5) % 2 === 0) text('PERFECT !', W / 2, 380, 18, '#ff4466', 'center');
      } else {
        text('STAGE CLEAR', W / 2, H / 2, 16, '#ffd23a', 'center');
      }
    }
    if (game.overT > 0) text('GAME OVER', W / 2, H / 2, 24, '#ff4466', 'center');
  }

  function drawTitle() {
    const bob = Math.sin(game.time * 2) * 4;
    text('STAR', W / 2, 130 + bob, 44, '#55ccff', 'center');
    text('STRIKE', W / 2, 188 + bob, 44, '#ff4466', 'center');
    text('ARCADE SPACE SHOOTER', W / 2, 238, 10, '#9fb4d6', 'center');

    text('FORMATION / DIVE', W / 2, 282, 8, '#7f95b5', 'center');
    const rows = [
      ['boss', '150 / 400'],
      ['butterfly', '80 / 160'],
      ['bee', '50 / 100'],
    ];
    rows.forEach(([t, label], i) => {
      const y = 322 + i * 40;
      const f = Math.floor(game.time * 4) % 2;
      drawSprite(getSprite(t, f), 150, y);
      text(label + ' PTS', 200, y, 11, '#ffffff');
    });

    text('HI-SCORE', W / 2, 452, 10, '#ff4466', 'center');
    text(String(game.hi).padStart(6, '0'), W / 2, 474, 12, '#ffffff', 'center');

    if (Math.floor(game.time * 2) % 2 === 0) text('PRESS ENTER OR TAP', W / 2, 530, 14, '#ffd23a', 'center');
    text('ARROWS / A D : MOVE', W / 2, 574, 9, '#7f95b5', 'center');
    text('SPACE / Z : FIRE', W / 2, 592, 9, '#7f95b5', 'center');
    text('P : PAUSE   M : MUTE', W / 2, 610, 9, '#7f95b5', 'center');
  }

  function drawGameOver() {
    text('GAME OVER', W / 2, 200, 30, '#ff4466', 'center');
    text('SCORE', W / 2, 280, 12, '#55ccff', 'center');
    text(String(game.score).padStart(6, '0'), W / 2, 310, 20, '#ffffff', 'center');
    text('STAGE ' + game.stage, W / 2, 352, 12, '#9fb4d6', 'center');
    if (game.score > 0 && game.score >= game.hi) {
      if (Math.floor(game.time * 4) % 2 === 0) text('NEW HI-SCORE!', W / 2, 400, 14, '#ffd23a', 'center');
    } else {
      text('HI-SCORE ' + String(game.hi).padStart(6, '0'), W / 2, 400, 11, '#ffffff', 'center');
    }
    if (game.lockT <= 0 && Math.floor(game.time * 2) % 2 === 0) {
      text('PRESS ENTER OR TAP', W / 2, 500, 14, '#ffd23a', 'center');
    }
  }

  function draw() {
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, W, H);
    drawStars();

    if (game.state === 'title') { drawTitle(); return; }

    ctx.save();
    if (game.shake > 0) ctx.translate(rand(-4, 4) * game.shake * 2, rand(-4, 4) * game.shake * 2);

    if (game.state === 'gameover') {
      drawParticles();
      ctx.restore();
      drawGameOver();
      return;
    }

    drawPowerups();
    for (const e of game.enemies) drawEnemy(e);
    drawBullets();
    drawPlayer();
    drawParticles();
    ctx.restore();

    drawHUD();
    drawBanners();

    if (game.state === 'paused') {
      ctx.fillStyle = 'rgba(0,0,10,0.65)';
      ctx.fillRect(0, 0, W, H);
      text('PAUSED', W / 2, H / 2 - 10, 26, '#ffffff', 'center');
      text('PRESS P / ENTER', W / 2, H / 2 + 34, 11, '#ffd23a', 'center');
    }
  }

  /* ---------------------------------------------------------
     메인 루프
     --------------------------------------------------------- */
  let last = performance.now();
  function frame(now) {
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    update(dt);
    draw();
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
})();
