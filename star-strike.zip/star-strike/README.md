# ⭐ STAR STRIKE

고전 아케이드 **갤러거(Galaga) 스타일**의 우주 슈팅 게임입니다.
순수 **HTML + CSS + JavaScript**(Canvas)만 사용했고, 빌드 과정·외부 라이브러리·이미지/사운드 파일이 없습니다.

[![CI](../../actions/workflows/ci.yml/badge.svg)](../../actions/workflows/ci.yml)

## 플레이

- 로컬: `index.html`을 브라우저에서 열면 바로 실행됩니다.
- 배포 후: `https://<사용자명>.github.io/<저장소명>/`

## 조작법

| 키 | 동작 |
| --- | --- |
| `←` `→` / `A` `D` | 이동 |
| `Space` / `Z` / `↑` | 발사 (누르고 있으면 연사) |
| `Enter` | 게임 시작 / 재시작 |
| `P` / `Esc` | 일시정지 |
| `M` | 소리 켜기/끄기 |

모바일에서는 화면 하단의 터치 버튼(◀ ▶ FIRE)을 사용합니다.

## 게임 규칙

- 적 편대가 곡선 경로로 등장해 대형을 이루고, 이후 하나둘 플레이어를 향해 **급강하 공격**을 합니다.
- **보스(초록)** 는 2번 맞춰야 하며, 급강하할 때 나비 호위기를 함께 데려옵니다.
- 급강하 중인 보스를 격추하면 **DUAL 아이템**이 떨어집니다. 먹으면 14초 동안 전투기가 2대로 늘어나 동시에 발사합니다.
- **스테이지 3, 7, 11…** 은 *챌린징 스테이지* 입니다. 적이 공격하지 않고 지나가며, 40마리를 모두 맞추면 **PERFECT 보너스 10,000점**!
- 2만 점에서 첫 번째 추가 목숨, 이후 7만 점마다 추가 목숨을 얻습니다.

| 적 | 대형 점수 | 급강하 점수 |
| --- | --- | --- |
| 보스 | 150 | 400 |
| 나비 | 80 | 160 |
| 벌 | 50 | 100 |

최고 점수는 브라우저 `localStorage`에 저장됩니다.

## 프로젝트 구조

```
star-strike/
├── index.html                  # 페이지 구조, 터치 컨트롤
├── css/
│   └── style.css               # 레이아웃 / 반응형 스타일
├── js/
│   └── game.js                 # 게임 로직 (스프라이트, 사운드, AI, 충돌, 렌더링)
├── .github/
│   └── workflows/
│       ├── ci.yml              # push / PR 시 문법 검사
│       └── pages.yml           # main 브랜치 push 시 GitHub Pages 배포
├── .editorconfig               # 에디터 공통 설정
├── .gitignore
├── LICENSE                     # MIT
├── package.json                # 개발용 스크립트 (의존성 없음)
└── README.md
```

## 개발하기

의존성 설치는 필요 없습니다. Node.js(18+)가 있으면 아래 스크립트를 쓸 수 있습니다.

```bash
npm start        # 로컬 서버 실행 (npx serve .)
npm run check    # js/game.js 문법 검사
```

`js/game.js`는 영역별로 주석 구분선이 있어 찾기 쉽습니다.

| 영역 | 내용 |
| --- | --- |
| 유틸 | 난수, clamp, 베지어 곡선 |
| 픽셀 스프라이트 | 문자열 도트 → 캔버스 (`SPR`, `PAL`) |
| 사운드 | WebAudio 효과음 (`sfx`) |
| 게임 데이터 | 편대 배치 `FORMATION`, 적 종류 `TYPES`, 상태 `game`/`player` |
| 게임 흐름 | 시작, 스테이지 생성, 점수 |
| 입력 | 키보드 / 터치 |
| 플레이어 / 적 | 이동, 사격, 급강하 AI |
| 업데이트 | 충돌, 스테이지 클리어, 게임오버 |
| 그리기 | 화면 렌더링, HUD, 타이틀 |

### 커스터마이징 팁

- 적 배치/종류: `FORMATION`, `TYPES`
- 난이도: `enemyAI()`의 급강하 간격, `bulletSpeed()`, `maxEnemyBullets()`
- 스프라이트: `SPR`의 문자열 도트와 `PAL` 팔레트를 수정

## GitHub에 올리기

```bash
git init
git add .
git commit -m "Initial commit: STAR STRIKE"
git branch -M main
git remote add origin https://github.com/<사용자명>/<저장소명>.git
git push -u origin main
```

### GitHub Pages 배포

1. 저장소 **Settings → Pages → Build and deployment → Source** 를 **GitHub Actions** 로 설정합니다.
2. `main` 브랜치에 push 하면 `.github/workflows/pages.yml`이 자동으로 배포합니다.

## 기여하기

1. 저장소를 fork 하고 기능 브랜치를 만듭니다. (`git checkout -b feature/my-change`)
2. 변경 후 `npm run check`로 문법을 확인합니다.
3. Pull Request를 보내면 CI가 자동으로 검사합니다.

## 라이선스

[MIT](LICENSE)
